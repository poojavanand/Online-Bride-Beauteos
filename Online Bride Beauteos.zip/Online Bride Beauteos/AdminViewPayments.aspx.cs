﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class AdminViewPayments : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                con.Open();
                string str = "select * from Bookings";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                GridView1.DataSource = dt;
                DataBind();
                con.Close();
                con.Open();
                string str1 = "select sum(Advance_Paid),sum(Balance) from Bookings";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader reader1 = cmd1.ExecuteReader();
                reader1.Read();
                if (reader1.HasRows)
                {
                    lblcollected.Text = "Total Amount Collected : Rs," + reader1.GetValue(0).ToString();
                    lblbalance.Text = "Total Balance To Be Collected : Rs," + reader1.GetValue(1).ToString();
                }
                else
                {
                    GridView1.DataSource = null;
                    DataBind();
                    lblcollected.Text = "";
                    lblbalance.Text = "";
                }
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
}