﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class AdminAddBridePackage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    int packageid;
    public void GeneratePackageID()
    {
        try
        {
            con.Open();
            string str = "select max(PackageID) from Packages";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.IsDBNull(0))
            {
                packageid = 7651;
            }
            else
            {


                packageid = Convert.ToInt32(reader.GetValue(0));
                packageid++;
            }
            con.Close();
            lblpid.Text = packageid.ToString();
        }
        catch (Exception e1)
        {
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
               GeneratePackageID();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {
            string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            string imagepath;
            if (!FileUpload1.HasFile)
            {
                lblpicture.Text = "Please Select Bride_Package Photo in JPG Format";
            }
            else
            {
                bool exist = false;
                con.Open();
                string str1 = "select * from Packages where Package_Name=@pname and Package_Content=@ptype";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                cmd1.Parameters.Add("@pname", txtpackagename.Text.Trim());
                cmd1.Parameters.Add("@ptype", txtpackagecontent.Text.Trim());
                SqlDataReader reader1 = cmd1.ExecuteReader();
                reader1.Read();
                if (reader1.HasRows)
                {
                    exist = true;
                }
                con.Close();
                if (exist == false)
                {
                    con.Open();
                    string str = "insert into Packages values(@pid,@pname,@content,@price,@picture)";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.Parameters.Add("@pid", Convert.ToInt32(lblpid.Text));
                    cmd.Parameters.Add("@pname", txtpackagename.Text.Trim());
                    cmd.Parameters.Add("@content", txtpackagecontent.Text.Trim());
                    cmd.Parameters.Add("@price", Convert.ToDouble(txtcost.Text.Trim()));
                    FileUpload1.SaveAs(Server.MapPath("~/packages/" + lblpid.Text + ext));
                    imagepath = "~/packages/" + lblpid.Text + ext;
                    cmd.Parameters.Add("@picture", imagepath);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Bride Beauty Package Details Saved Successfully ! ! !');</script>");
                    txtcost.Text = "";
                    txtpackagename.Text = "";
                    txtpackagecontent.Text = "";
                    GeneratePackageID();
                }
                else
                {
                    Response.Write("<script>alert('This Beauty Package Details Are Already Exist ! ! !');</script>");

                }

            }
        }
        catch (Exception e1)
        {
        }
    }
}