﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerViewBridePackages : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                con.Open();
                string str1 = "select Picture,Package_Cost from Packages";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                DataList1.DataSource = dt;
                DataBind();
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
}