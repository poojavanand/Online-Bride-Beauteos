﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class AdminUpdateBridePackage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlpid.Items.Add("--Select--");
                con.Open();
                string str = "select PackageID from Packages";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlpid.Items.Add(reader.GetValue(0).ToString());
                }
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlpid_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Packages where PackageID=" + ddlpid.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            txtpackagename.Text = reader.GetString(1).Trim();
            txtpackagecontent.Text = reader.GetString(2).Trim();
            txtcost.Text = reader.GetValue(3).ToString();
            Image7.ImageUrl = reader.GetString(4).ToString();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            con.Open();
            string str = "update Packages set Package_Name=@pname,Package_Content=@content,Package_Cost=@price where PackageID=@pid";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.Parameters.Add("@pid", Convert.ToInt32(ddlpid.Text));
            cmd.Parameters.Add("@pname", txtpackagename.Text.Trim());
            cmd.Parameters.Add("@content", txtpackagecontent.Text.Trim());
            cmd.Parameters.Add("@price", Convert.ToDouble(txtcost.Text.Trim()));
            cmd.ExecuteNonQuery();
            con.Close();
            if (FileUpload1.HasFile)
            {
                FileUpload1.SaveAs(Server.MapPath("~/packages/" + ddlpid.Text + ext));
            }
            Response.Write("<script>alert('Bride Package Details Updated Successfully ! ! !');</script>");
        }
        catch (Exception e1)
        {
        }
    }
}