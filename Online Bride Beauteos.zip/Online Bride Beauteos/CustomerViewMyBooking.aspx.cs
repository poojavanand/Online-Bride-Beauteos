﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerViewMyBooking : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtbookingid.Text == "")
            {
                GridView1.DataSource = null;
                DataBind();
                Image8.ImageUrl = null;
                Response.Write("<script>alert('Please Enter Your BookingID! ! !');</script>");
            }
            else
            {
                con.Open();
                string str = "select * from Bookings where BookingID=" + txtbookingid.Text.Trim();
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    Session["image"] = dt.Rows[0][14].ToString();
                    GridView1.DataSource = dt;
                    DataBind();
                    Image8.ImageUrl = Session["image"].ToString();
                }
                else
                {
                    GridView1.DataSource = null;
                    DataBind();
                    Image8.ImageUrl = null;
                    Response.Write("<script>alert('BookingID Not Found Or Incorrect Booking ID! ! !');</script>");
                }
                con.Close();

            }
        }
        catch (Exception e1)
        {
        }
    }
}