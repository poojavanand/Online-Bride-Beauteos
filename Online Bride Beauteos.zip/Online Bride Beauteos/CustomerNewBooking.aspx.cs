﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class CustomerNewBooking : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    int bookingid;
    public void GenerateBookingID()
    {
        try
        {
            con.Open();
            string str = "select max(ID) from BookingID";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (reader.IsDBNull(0))
            {
                bookingid = 90001;
            }
            else
            {


                bookingid = Convert.ToInt32(reader.GetValue(0));
                bookingid++;
            }
            con.Close();
            lblbookingid.Text = bookingid.ToString();
        }
        catch (Exception e1)
        {
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlpackagename.Items.Add("--Select--");
                con.Open();
                string str = "select Package_Name from Packages";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlpackagename.Items.Add(reader.GetString(0).Trim());
                }
                con.Close();
                GenerateBookingID();
                lbldob.Text = DateTime.Now.ToShortDateString();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlpackagename_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlpackagename.Text == "--Select--")
            {
                 lblpackageid.Text = "";
                txtpackagecontent.Text = "";
                lblpackagecost.Text = "";
                Image7.ImageUrl = null;
                Response.Write("<script>alert('Please Select The Package Name For Booking ! ! !');</script>");
            }
            else
            {
                con.Open();
                string str = "select * from Packages where Package_Name='" + ddlpackagename.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                lblpackageid.Text = reader.GetValue(0).ToString();
                txtpackagecontent.Text = reader.GetString(2).Trim();
                lblpackagecost.Text = reader.GetValue(3).ToString();
                Image7.ImageUrl = reader.GetString(4).ToString();
                Session["image"] = reader.GetString(4).ToString();
                con.Close();
                double packagecost = 0, advance = 0, balance = 0;
                packagecost = Convert.ToDouble(lblpackagecost.Text);
                advance = packagecost / 2;
                lbladvance.Text = advance.ToString();
                balance = packagecost - advance;
                lblbalance.Text = balance.ToString();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnbook_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (ddlpackagename.Text == "--Select--")
            {
                Response.Write("<script>alert('Please Select The Package Name For Booking ! ! !');</script>");
            }
            else
            {

                DateTime groomindate, cd;
                cd = Convert.ToDateTime(lbldob.Text);
                cd = Convert.ToDateTime(cd.ToShortDateString());
                groomindate = Convert.ToDateTime(dateofgrooming.Text.Trim());
                groomindate = Convert.ToDateTime(groomindate.ToShortDateString());
                if (groomindate <= cd)
                {
                    Response.Write("<script>alert('Grooming Date Must Be Atleast 1 Day Prior To Booking Date ! ! !');</script>");
                }
                else
                {
                    string status = "Booked";
                    con.Open();
                    string str = "insert into Bookings values(@bid,@pid,@pname,@pcontent,@pcost,@cname,@add,@mno,@eid,@advance,@balance,@dob,@dog,@status,@picture)";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.Parameters.Add("@bid", Convert.ToInt32(lblbookingid.Text));
                    cmd.Parameters.Add("@pid", Convert.ToInt32(lblpackageid.Text));
                    cmd.Parameters.Add("@pname", ddlpackagename.Text);
                    cmd.Parameters.Add("@pcontent", txtpackagecontent.Text.Trim());
                    cmd.Parameters.Add("@pcost", Convert.ToDouble(lblpackagecost.Text));
                    cmd.Parameters.Add("@cname", txtcustomername.Text.Trim());
                    cmd.Parameters.Add("@add", txtaddress.Text.Trim());
                    cmd.Parameters.Add("@mno", txtmno.Text.Trim());
                    cmd.Parameters.Add("@eid", txteid.Text.Trim());
                    cmd.Parameters.Add("@advance", Convert.ToDouble(lbladvance.Text.Trim()));
                    cmd.Parameters.Add("@balance", Convert.ToDouble(lblbalance.Text));
                    cmd.Parameters.Add("@dob", cd.ToShortDateString());
                    cmd.Parameters.Add("@dog", groomindate.ToShortDateString());
                    cmd.Parameters.Add("@status", status);
                    cmd.Parameters.Add("@picture", Session["image"].ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    con.Open();
                    string str1 = "insert into BookingID values(@id)";
                    SqlCommand cmd1 = new SqlCommand(str1, con);
                    cmd1.Parameters.Add("@id", Convert.ToInt32(lblbookingid.Text));
                    cmd1.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("CustomerBookingConfirmation.aspx?id=" + lblbookingid.Text);
                }
            }

        }
        catch (Exception e1)
        {
        }
    }
}