﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class CustomerUpdateBooking : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlpackagename.Items.Add("--Select--");
                con.Open();
                string str = "select Package_Name from Packages";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlpackagename.Items.Add(reader.GetString(0).Trim());
                }
                con.Close();
                lbldob.Text = DateTime.Now.ToShortDateString();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlpackagename_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlpackagename.Text == "--Select--")
            {
                lblpackageid.Text = "";
                txtpackagecontent.Text = "";
                lblpackagecost.Text = "";
                Image7.ImageUrl = null;
                Response.Write("<script>alert('Please Select The Package Name For Booking ! ! !');</script>");
            }
            else
            {
                con.Open();
                string str = "select * from Packages where Package_Name='" + ddlpackagename.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                lblpackageid.Text = reader.GetValue(0).ToString();
                txtpackagecontent.Text = reader.GetString(2).Trim();
                lblpackagecost.Text = reader.GetValue(3).ToString();
                Image7.ImageUrl = reader.GetString(4).ToString();
                Session["image"] = reader.GetString(4).ToString();
                con.Close();


                double packagecost = 0, advance = 0, balance = 0;
                packagecost = Convert.ToDouble(lblpackagecost.Text);
                advance = packagecost / 2;
                lblnewadvance.Text = advance.ToString();
                balance = packagecost - advance;
                lblnewbalance.Text = balance.ToString();

                double oldadv = 0,newadvance=0, newbal = 0, variation = 0;
               

                oldadv = Convert.ToDouble(lbladvance.Text);
                newadvance = Convert.ToDouble(lblnewadvance.Text);
                if (newadvance > oldadv)
                {
                    variation = advance - oldadv;
                    newbal = balance + variation;

                }
                else if (newadvance < oldadv)
                {
                    variation = oldadv - advance;
                    newbal = balance - variation;
                }
                lblnewbalance.Text = newbal.ToString();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtbookingid.Text == "")
            {

                Response.Write("<script>alert('Please Enter Your BookingID! ! !');</script>");
            }
            else
            {
                con.Open();
                string str = "select * from Bookings where BookingID=" + txtbookingid.Text.Trim();
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    lblpackageid.Text = reader.GetValue(1).ToString();
                    ddlpackagename.Text = reader.GetString(2).Trim();
                    txtpackagecontent.Text = reader.GetString(3).Trim();
                    lblpackagecost.Text = reader.GetValue(4).ToString();
                    txtcustomername.Text = reader.GetString(5).Trim();
                    txtaddress.Text = reader.GetString(6).Trim();
                    txtmno.Text = reader.GetString(7).Trim();
                    txteid.Text = reader.GetString(8).Trim();
                    lbladvance.Text = reader.GetValue(9).ToString();
                    lblbalance.Text = reader.GetValue(10).ToString();
                    dateofgrooming.Text = reader.GetDateTime(12).ToShortDateString();
                    Image7.ImageUrl = reader.GetString(14).Trim();
                    Session["image"] = reader.GetString(14).ToString();
                    lblnewadvance.Text = "";
                    lblnewbalance.Text = reader.GetValue(10).ToString();

                }
                else
                {
                    lblpackageid.Text = "";
                    ddlpackagename.Text = "--Select--";
                    txtpackagecontent.Text = "";
                    lblpackagecost.Text = "";
                    txtcustomername.Text = "";
                    txtaddress.Text = "";
                    txtmno.Text = "";
                    txteid.Text = "";
                    lbladvance.Text = "";
                    lblbalance.Text = "";
                    dateofgrooming.Text = "";
                    Image7.ImageUrl = null;
                    lblnewadvance.Text = "";
                    lblnewbalance.Text = "";
                    Response.Write("<script>alert('Sorry Incorrect BookingID! ! !');</script>");
                }
                con.Close();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime groomindate, cd;
            cd = Convert.ToDateTime(lbldob.Text);
            cd = Convert.ToDateTime(cd.ToShortDateString());
            groomindate = Convert.ToDateTime(dateofgrooming.Text.Trim());
            groomindate = Convert.ToDateTime(groomindate.ToShortDateString());
            if (groomindate <= cd)
            {
                Response.Write("<script>alert('Grooming Date Must Be Atleast 1 Day Prior To Booking Date ! ! !');</script>");
            }
            else
            {
                con.Open();
                string str1 = "delete from Bookings where BookingId=" + txtbookingid.Text.Trim();
                SqlCommand cmd1 = new SqlCommand(str1, con);
                cmd1.ExecuteNonQuery();
                con.Close();

                string status = "Booking Updated";
                con.Open();
                string str = "insert into Bookings values(@bid,@pid,@pname,@pcontent,@pcost,@cname,@add,@mno,@eid,@advance,@balance,@dob,@dog,@status,@picture)";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.Parameters.Add("@bid", Convert.ToInt32(txtbookingid.Text));
                cmd.Parameters.Add("@pid", Convert.ToInt32(lblpackageid.Text));
                cmd.Parameters.Add("@pname", ddlpackagename.Text);
                cmd.Parameters.Add("@pcontent", txtpackagecontent.Text.Trim());
                cmd.Parameters.Add("@pcost", Convert.ToDouble(lblpackagecost.Text));
                cmd.Parameters.Add("@cname", txtcustomername.Text.Trim());
                cmd.Parameters.Add("@add", txtaddress.Text.Trim());
                cmd.Parameters.Add("@mno", txtmno.Text.Trim());
                cmd.Parameters.Add("@eid", txteid.Text.Trim());
                cmd.Parameters.Add("@advance", Convert.ToDouble(lbladvance.Text.Trim()));
                cmd.Parameters.Add("@balance", Convert.ToDouble(lblnewbalance.Text));
                cmd.Parameters.Add("@dob", cd.ToShortDateString());
                cmd.Parameters.Add("@dog", groomindate.ToShortDateString());
                cmd.Parameters.Add("@status", status);
                cmd.Parameters.Add("@picture", Session["image"].ToString());
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Booking Details Updated Successfully! ! !');</script>");

            }
        }
        catch (Exception e1)
        {
        }
    }
}