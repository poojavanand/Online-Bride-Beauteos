﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class AdminRemoveBridePackage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=EBrideBeauteous;Integrated Security=True");
    public void loadpackageid()
    {
        try
        {
           
                ddlpid.Items.Clear();
                ddlpid.Items.Add("--Select--");
                con.Open();
                string str = "select PackageID from Packages";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddlpid.Items.Add(reader.GetValue(0).ToString());
                }
                con.Close();
           
        }
        catch (Exception e1)
        {
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                loadpackageid();
            }
        }
        catch (Exception e1)
        {
        }
    }
    protected void ddlpid_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "select * from Packages where PackageID=" + ddlpid.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter dap = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            Session["imagepath"] = dt.Rows[0][4].ToString();
            GridView1.DataSource = dt;
            DataBind();
            con.Close();
        }
        catch (Exception e1)
        {
        }
    }
    protected void btnremove_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            string str = "delete from Packages where PackageID=" + ddlpid.Text;
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            con.Close();
            File.Delete(Server.MapPath(Session["imagepath"].ToString()));
            loadpackageid();
            GridView1.DataSource = null;
            DataBind();
            Response.Write("<script>alert('Bride Package Details Removed Successfully ! ! !');</script>");
        }
        catch (Exception e1)
        {
        }
    }
}